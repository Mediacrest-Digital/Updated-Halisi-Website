from django.contrib import admin
from apps.website.models import *
# Register your models here.


admin.site.register(Service)
admin.site.register(Package)
